const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');

  if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });
    req.on('end', () => {
      console.log('Reservación recibida:');
      try {
        console.log(JSON.parse(body));
      } catch (e) {
        console.log(body);
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ mensaje: 'Reservación recibida con éxito' }));
    });
    return;
  }

  let archivo = req.url === '/' ? 'index.html' : req.url.replace('/', '');
  let ruta = path.join(__dirname, archivo);

  fs.readFile(ruta, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Archivo no encontrado');
    } else {
      if (archivo.endsWith('.css')) {
        res.writeHead(200, { 'Content-Type': 'text/css' });
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
      }
      res.end(data);
    }
  });
});

server.listen(5000, () => {
  console.log('Servidor corriendo en http://localhost:5000');
});
